package log

func Init() {
	initm()
	initd()
}
